
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1">
            <div className="text-2xl font-pacifico text-pink-600 mb-4">
              Fasa Brides & Beyond
            </div>
            <p className="text-gray-600 mb-4">
              Transforming brides, one makeover at a time. Where beauty meets elegance for your perfect wedding day.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 flex items-center justify-center bg-pink-600 text-white rounded-full hover:bg-pink-700 transition-colors cursor-pointer">
                <i className="ri-instagram-fill"></i>
              </a>
              <a href="#" className="w-10 h-10 flex items-center justify-center bg-pink-600 text-white rounded-full hover:bg-pink-700 transition-colors cursor-pointer">
                <i className="ri-facebook-fill"></i>
              </a>
              <a href="#" className="w-10 h-10 flex items-center justify-center bg-pink-600 text-white rounded-full hover:bg-pink-700 transition-colors cursor-pointer">
                <i className="ri-pinterest-fill"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Services</h3>
            <ul className="space-y-2 text-gray-600">
              <li><Link href="/services" className="hover:text-pink-600 transition-colors cursor-pointer">Bridal Makeup</Link></li>
              <li><Link href="/services" className="hover:text-pink-600 transition-colors cursor-pointer">Hair Styling</Link></li>
              <li><Link href="/services" className="hover:text-pink-600 transition-colors cursor-pointer">Bridal Packages</Link></li>
              <li><Link href="/services" className="hover:text-pink-600 transition-colors cursor-pointer">Trial Sessions</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Links</h3>
            <ul className="space-y-2 text-gray-600">
              <li><Link href="/portfolio" className="hover:text-pink-600 transition-colors cursor-pointer">Portfolio</Link></li>
              <li><Link href="/about" className="hover:text-pink-600 transition-colors cursor-pointer">About Us</Link></li>
              <li><Link href="/contact" className="hover:text-pink-600 transition-colors cursor-pointer">Contact</Link></li>
              <li><Link href="/booking" className="hover:text-pink-600 transition-colors cursor-pointer">Book Appointment</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Info</h3>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-center">
                <i className="ri-phone-line mr-2"></i>
                (555) 123-4567
              </li>
              <li className="flex items-center">
                <i className="ri-mail-line mr-2"></i>
                hello@fasabridesandbeyond.com
              </li>
              <li className="flex items-center">
                <i className="ri-map-pin-line mr-2"></i>
                123 Beauty Lane, Fashion District
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center text-gray-600">
          <p>&copy; 2024 Fasa Brides & Beyond. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
