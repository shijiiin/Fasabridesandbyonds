
'use client';

export default function TestimonialsSection() {
  const testimonials = [
    {
      name: 'Emma Johnson',
      image: 'https://readdy.ai/api/search-image?query=Beautiful%20happy%20bride%20portrait%20with%20professional%20makeup%20and%20hairstyle%2C%20smiling%20bride%20with%20elegant%20wedding%20look%2C%20radiant%20bride%20after%20makeover%2C%20wedding%20photography%20portrait%2C%20bride%20with%20natural%20glowing%20makeup&width=150&height=150&seq=bride1&orientation=squarish',
      text: 'Absolutely stunning work! The team made me feel like a princess on my wedding day. The makeup lasted all night and looked flawless in every photo.',
      rating: 5
    },
    {
      name: 'Sarah Williams',
      image: 'https://readdy.ai/api/search-image?query=Elegant%20bride%20with%20sophisticated%20makeup%20look%2C%20professional%20bridal%20portrait%2C%20bride%20with%20classic%20wedding%20hairstyle%2C%20beautiful%20bride%20after%20professional%20makeover%2C%20wedding%20day%20beauty%20portrait&width=150&height=150&seq=bride2&orientation=squarish',
      text: 'Professional, talented, and so sweet! They listened to exactly what I wanted and exceeded my expectations. Highly recommend for any bride!',
      rating: 5
    },
    {
      name: 'Jessica Davis',
      image: 'https://readdy.ai/api/search-image?query=Radiant%20bride%20with%20natural%20makeup%20look%2C%20bride%20with%20romantic%20hairstyle%2C%20professional%20wedding%20makeup%20portrait%2C%20glowing%20bride%20after%20beauty%20session%2C%20elegant%20bridal%20photography&width=150&height=150&seq=bride3&orientation=squarish',
      text: 'The trial session was perfect - we worked together to create my dream look. On the wedding day, everything was executed flawlessly!',
      rating: 5
    }
  ];

  return (
    <section className="py-20 bg-pink-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            What Our Brides Say
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Don't just take our word for it. Here's what our beautiful brides have to say about their experience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="flex items-center mb-6">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name}
                  className="w-16 h-16 rounded-full object-cover object-top mr-4"
                />
                <div>
                  <h4 className="text-lg font-semibold text-gray-900">{testimonial.name}</h4>
                  <div className="flex">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <i key={i} className="ri-star-fill text-yellow-500"></i>
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-600 italic">"{testimonial.text}"</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-lg text-gray-600 mb-6">Ready to join our happy brides?</p>
          <a href="/booking" className="bg-pink-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-pink-700 transition-colors cursor-pointer whitespace-nowrap">
            Get Ready to Shine on Your Big Day
          </a>
        </div>
      </div>
    </section>
  );
}
