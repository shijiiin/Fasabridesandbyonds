
'use client';

import Link from 'next/link';

export default function ServicesSection() {
  const services = [
    {
      icon: 'ri-brush-line',
      title: 'Bridal Makeup',
      description: 'Professional makeup artistry tailored to your unique style and wedding theme.',
      price: 'From $150',
      image: 'https://readdy.ai/api/search-image?query=Professional%20bridal%20makeup%20artist%20applying%20makeup%20to%20beautiful%20bride%2C%20elegant%20makeup%20brushes%20and%20cosmetics%2C%20luxurious%20bridal%20beauty%20preparation%2C%20soft%20natural%20lighting%2C%20makeup%20artist%20working%20on%20bride%20face%2C%20wedding%20makeup%20session%20in%20progress&width=400&height=300&seq=service1&orientation=landscape'
    },
    {
      icon: 'ri-scissors-line',
      title: 'Hair Styling',
      description: 'Elegant bridal hairstyles from classic updos to modern romantic looks.',
      price: 'From $120',
      image: 'https://readdy.ai/api/search-image?query=Professional%20hair%20stylist%20creating%20elegant%20bridal%20hairstyle%2C%20beautiful%20bride%20with%20wedding%20hair%20updo%2C%20luxury%20bridal%20hair%20styling%20session%2C%20romantic%20wedding%20hairstyle%20preparation%2C%20soft%20curls%20and%20braids%2C%20bridal%20beauty%20salon&width=400&height=300&seq=service2&orientation=landscape'
    },
    {
      icon: 'ri-gift-line',
      title: 'Complete Packages',
      description: 'All-inclusive bridal beauty packages for your perfect wedding day.',
      price: 'From $250',
      image: 'https://readdy.ai/api/search-image?query=Complete%20bridal%20makeover%20transformation%2C%20before%20and%20after%20bridal%20beauty%20session%2C%20full%20service%20bridal%20preparation%2C%20elegant%20bride%20getting%20complete%20makeover%2C%20luxury%20bridal%20package%20experience%2C%20wedding%20beauty%20transformation&width=400&height=300&seq=service3&orientation=landscape'
    },
    {
      icon: 'ri-calendar-line',
      title: 'Trial Sessions',
      description: 'Perfect your look with a pre-wedding trial session.',
      price: 'From $80',
      image: 'https://readdy.ai/api/search-image?query=Bridal%20makeup%20trial%20session%2C%20bride%20testing%20wedding%20makeup%20look%2C%20makeup%20artist%20consultation%20with%20bride%2C%20bridal%20beauty%20trial%20appointment%2C%20wedding%20makeup%20rehearsal%2C%20professional%20makeup%20testing%20session&width=400&height=300&seq=service4&orientation=landscape'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Our Bridal Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover our comprehensive range of bridal beauty services designed to make you shine on your special day.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <div className="h-48 bg-cover bg-center bg-top" style={{backgroundImage: `url('${service.image}')`}}></div>
              <div className="p-6">
                <div className="w-12 h-12 flex items-center justify-center bg-pink-100 rounded-full mb-4">
                  <i className={`${service.icon} text-2xl text-pink-600`}></i>
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-pink-600">{service.price}</span>
                  <Link href="/booking" className="bg-pink-600 text-white px-4 py-2 rounded-full hover:bg-pink-700 transition-colors cursor-pointer whitespace-nowrap">
                    Book Now
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/services" className="bg-pink-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-pink-700 transition-colors cursor-pointer whitespace-nowrap">
            View All Services
          </Link>
        </div>
      </div>
    </section>
  );
}
