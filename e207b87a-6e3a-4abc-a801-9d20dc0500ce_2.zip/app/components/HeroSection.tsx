
'use client';

import Link from 'next/link';

export default function HeroSection() {
  return (
    <section 
      className="relative min-h-screen flex items-center justify-center bg-cover bg-center"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.3), rgba(0, 0, 0, 0.3)), url('https://readdy.ai/api/search-image?query=Elegant%20bridal%20makeup%20artist%20studio%20with%20soft%20natural%20lighting%2C%20beautiful%20bride%20getting%20ready%2C%20professional%20makeup%20artist%20applying%20makeup%20to%20bride%20in%20white%20dress%2C%20luxury%20bridal%20suite%20with%20mirrors%20and%20flowers%2C%20romantic%20wedding%20preparation%20atmosphere%2C%20soft%20pink%20and%20white%20color%20palette%2C%20high-end%20beauty%20salon%20interior&width=1920&height=1080&seq=hero1&orientation=landscape')`
      }}
    >
      <div className="w-full max-w-7xl mx-auto px-6 text-center text-white">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
          Blossom into the bride <br />
          <span className="text-pink-300">you've always dreamed of</span>
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed">
          Where beauty meets elegance. Transform into your most radiant self with our expert bridal makeover services.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Link href="/booking" className="bg-pink-600 text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-pink-700 transition-colors cursor-pointer whitespace-nowrap">
            Book Your Makeover Today!
          </Link>
          <Link href="/portfolio" className="border-2 border-white text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-white hover:text-gray-900 transition-colors cursor-pointer whitespace-nowrap">
            View Our Work
          </Link>
        </div>
      </div>
    </section>
  );
}
