
'use client';

export default function InstagramSection() {
  const instagramPosts = [
    {
      image: 'https://readdy.ai/api/search-image?query=Beautiful%20bride%20getting%20makeup%20applied%20by%20professional%20makeup%20artist%2C%20elegant%20bridal%20makeup%20session%20behind%20the%20scenes%2C%20luxury%20bridal%20beauty%20preparation%2C%20soft%20natural%20lighting%2C%20professional%20makeup%20application%20process&width=300&height=300&seq=insta1&orientation=squarish',
      likes: '245',
      caption: 'Creating magic ✨ Behind the scenes of today\'s bridal session'
    },
    {
      image: 'https://readdy.ai/api/search-image?query=Stunning%20bridal%20makeup%20transformation%20before%20and%20after%20photos%2C%20professional%20wedding%20makeup%20results%2C%20elegant%20bride%20with%20flawless%20makeup%2C%20bridal%20beauty%20makeover%20results%2C%20wedding%20day%20makeup%20perfection&width=300&height=300&seq=insta2&orientation=squarish',
      likes: '389',
      caption: 'From beautiful to absolutely radiant 💕 #BridalTransformation'
    },
    {
      image: 'https://readdy.ai/api/search-image?query=Professional%20makeup%20brushes%20and%20luxury%20cosmetics%20arranged%20beautifully%2C%20high%20end%20bridal%20makeup%20products%2C%20elegant%20makeup%20artist%20tools%2C%20beauty%20products%20for%20wedding%20makeup%2C%20luxury%20cosmetics%20display&width=300&height=300&seq=insta3&orientation=squarish',
      likes: '156',
      caption: 'The tools behind the magic 💄 Only the finest products for our brides'
    },
    {
      image: 'https://readdy.ai/api/search-image?query=Elegant%20bride%20with%20romantic%20hairstyle%20getting%20final%20touch%20ups%2C%20professional%20hair%20stylist%20working%20on%20bridal%20hair%2C%20wedding%20hair%20styling%20session%2C%20bride%20with%20beautiful%20updo%20hairstyle%2C%20bridal%20hair%20preparation&width=300&height=300&seq=insta4&orientation=squarish',
      likes: '298',
      caption: 'Hair goals achieved ✨ This romantic updo is perfection'
    },
    {
      image: 'https://readdy.ai/api/search-image?query=Happy%20bride%20showing%20off%20her%20complete%20bridal%20makeover%2C%20radiant%20bride%20after%20professional%20makeup%20and%20hair%2C%20wedding%20day%20beauty%20transformation%20complete%2C%20glowing%20bride%20ready%20for%20ceremony%2C%20bridal%20makeover%20final%20result&width=300&height=300&seq=insta5&orientation=squarish',
      likes: '412',
      caption: 'Ready to say "I do" 👰‍♀️ Another gorgeous bride ready for her big day'
    },
    {
      image: 'https://readdy.ai/api/search-image?query=Bridal%20makeup%20trial%20session%20in%20progress%2C%20bride%20and%20makeup%20artist%20discussing%20wedding%20look%2C%20professional%20consultation%20for%20wedding%20makeup%2C%20bridal%20beauty%20planning%20session%2C%20makeup%20artist%20showing%20color%20options%20to%20bride&width=300&height=300&seq=insta6&orientation=squarish',
      likes: '178',
      caption: 'Trial session perfection! Planning the dream look 💭'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            Follow Our Journey
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Get daily inspiration and behind-the-scenes glimpses of our bridal transformations on Instagram.
          </p>
          <a 
            href="#" 
            className="inline-flex items-center bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-4 rounded-full text-lg font-semibold hover:from-purple-600 hover:to-pink-600 transition-all cursor-pointer whitespace-nowrap"
          >
            <i className="ri-instagram-fill mr-2"></i>
            Follow @BellaBridalStudio
          </a>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {instagramPosts.map((post, index) => (
            <div key={index} className="group relative overflow-hidden rounded-lg aspect-square cursor-pointer">
              <img 
                src={post.image} 
                alt={`Instagram post ${index + 1}`}
                className="w-full h-full object-cover object-top transition-transform group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <div className="text-white text-center">
                  <div className="flex items-center justify-center mb-2">
                    <i className="ri-heart-fill mr-1"></i>
                    <span>{post.likes}</span>
                  </div>
                  <p className="text-sm px-2">{post.caption}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
